# Simple two–stage genomic prediction workflow
# Stage 1: Mixed model → line BLUEs
#   y ~ env_id (fixed) + line_id (fixed) + (1 | line_id:env_id)
# Stage 2: 5–fold CV with caret using marker matrix + BLUEs
#
# Models:
#   - Ridge (glmnet, alpha = 0)         ~ RRBLUP-ish
#   - LASSO (glmnet, alpha = 1)
#   - Elastic Net (glmnet, alpha = 0.5)
#   - Random Forest (rf)
#   - XGBoost (xgbTree)
#   - SVR (svmRadial)
#   - Deep NN (mlpWeightDecayML, RSNNS backend)

library(dplyr)
library(lme4)
library(caret)
library(glmnet)
library(randomForest)
library(xgboost)
library(kernlab)

set.seed(123)  # for reproducibility

# -------------------------------------------------------------------
# Load data
# -------------------------------------------------------------------
pheno <- read.csv(
  "g2f_2023_phenotypic_clean_data.csv",
  stringsAsFactors = FALSE,
  check.names = FALSE
)

geno <- read.csv(
  "g2f_genotype_data.csv",
  stringsAsFactors = FALSE,
  check.names = FALSE
)

yield_col <- "Grain Yield (bu/A)"

# -------------------------------------------------------------------
# Basic phenotype cleaning + env/line IDs
# -------------------------------------------------------------------
pheno <- pheno %>%
  filter(
    !is.na(.data[[yield_col]]),
    !is.na(Pedigree)
  ) %>%
  mutate(
    env_id  = paste0(Year, "_", `Field-Location`),
    line_id = Pedigree
  )

pheno$env_id  <- factor(pheno$env_id)
pheno$line_id <- factor(pheno$line_id)

# -------------------------------------------------------------------
# Stage 1: BLUEs from mixed model
# -------------------------------------------------------------------
cat("\n[1] Fitting Stage 1 model for BLUEs...\n")

form_stage1 <- as.formula(
  paste0("`", yield_col, "` ~ env_id + line_id + (1|line_id:env_id)")
)

mod1 <- lmer(form_stage1, data = pheno)

cat("  Extracting BLUEs for each line...\n")

fx      <- summary(mod1)$coefficients
line_fx <- fx[grep("^line_id", rownames(fx)), , drop = FALSE]

line_blues <- data.frame(
  line_id = sub("line_id", "", rownames(line_fx)),
  BLUE    = line_fx[, "Estimate"],
  stringsAsFactors = FALSE
)

cat("  Number of lines with BLUEs:", nrow(line_blues), "\n")

# -------------------------------------------------------------------
# Match BLUEs with genotype matrix
# -------------------------------------------------------------------
gp <- inner_join(line_blues, geno, by = c("line_id" = "Taxa"))
cat("\n[2] Lines available for Stage 2:", nrow(gp), "\n")

y <- gp$BLUE
X <- as.matrix(gp[, -(1:2)])
storage.mode(X) <- "numeric"

# Mean impute missing marker values
for (j in 1:ncol(X)) {
  X[is.na(X[, j]), j] <- mean(X[, j], na.rm = TRUE)
}

# Remove monomorphic markers
var_ok <- apply(X, 2, sd, na.rm = TRUE) > 0
X      <- X[, var_ok, drop = FALSE]

X_df <- as.data.frame(X)

# -------------------------------------------------------------------
# caret 5-fold CV setup
# -------------------------------------------------------------------
cat("\n[3] Running caret 5-fold CV...\n")

train_ctrl <- trainControl(
  method          = "cv",
  number          = 5,
  savePredictions = "final"
)

results <- data.frame(
  Model = character(),
  Cor   = numeric(),
  RMSE  = numeric()
)

# -------------------------------------------------------------------
# Ridge (glmnet, alpha = 0)
# -------------------------------------------------------------------
cat("  - Ridge (glmnet, alpha = 0)\n")

ridge_grid <- expand.grid(
  alpha  = 0,
  lambda = 10^seq(-3, 3, length.out = 20)
)

fit_ridge <- caret::train(
  x         = X_df,
  y         = y,
  method    = "glmnet",
  trControl = train_ctrl,
  preProcess = c("center", "scale")
)

best_r <- fit_ridge$bestTune
sub_r  <- subset(
  fit_ridge$pred,
  alpha == best_r$alpha & lambda == best_r$lambda
)
sub_r <- sub_r[order(sub_r$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "Ridge (RRBLUP-like)",
    Cor   = cor(sub_r$obs, sub_r$pred),
    RMSE  = sqrt(mean((sub_r$obs - sub_r$pred)^2))
  )
)

# -------------------------------------------------------------------
# bayesian LASSO (blasso)
# -------------------------------------------------------------------
cat("  - bayesian LASSO (blasso)\n")


fit_blasso <- caret::train(
  x          = X_df,
  y          = y,
  method     = "blasso",
  trControl  = train_ctrl,
  preProcess = c("center", "scale")
)

best_l <- fit_blasso$bestTune
sub_l  <- subset(
  fit_blasso$pred,
  alpha == best_l$alpha & lambda == best_l$lambda
)
sub_l <- sub_l[order(sub_l$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "Bayesian LASSO",
    Cor   = cor(sub_l$obs, sub_l$pred),
    RMSE  = sqrt(mean((sub_l$obs - sub_l$pred)^2))
  )
)

# -------------------------------------------------------------------
# Elastic Net (glmnet, alpha = 0.5)
# -------------------------------------------------------------------
cat("  - Elastic Net (glmnet, alpha = 0.5)\n")

enet_grid <- expand.grid(
  alpha  = 0.5,
  lambda = 10^seq(-3, 3, length.out = 20)
)

fit_enet <- caret::train(
  x          = X_df,
  y          = y,
  method     = "glmnet",
  trControl  = train_ctrl,
  tuneGrid   = enet_grid,
  preProcess = c("center", "scale")
)

best_e <- fit_enet$bestTune
sub_e  <- subset(
  fit_enet$pred,
  alpha == best_e$alpha & lambda == best_e$lambda
)
sub_e <- sub_e[order(sub_e$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "Elastic Net",
    Cor   = cor(sub_e$obs, sub_e$pred),
    RMSE  = sqrt(mean((sub_e$obs - sub_e$pred)^2))
  )
)

# -------------------------------------------------------------------
# Random Forest
# -------------------------------------------------------------------
cat("  - Random Forest (rf)\n")

fit_rf <- caret::train(
  x         = X_df,
  y         = y,
  method    = "rf",
  trControl = train_ctrl,
  ntree     = 50
)

best_rf <- fit_rf$bestTune
sub_rf  <- subset(
  fit_rf$pred,
  mtry == best_rf$mtry
)
sub_rf <- sub_rf[order(sub_rf$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "Random Forest",
    Cor   = cor(sub_rf$obs, sub_rf$pred),
    RMSE  = sqrt(mean((sub_rf$obs - sub_rf$pred)^2))
  )
)

# -------------------------------------------------------------------
# XGBoost (xgbTree)
# -------------------------------------------------------------------
cat("  - Gradient Boosting (xgbTree)\n")

fit_xgb <- caret::train(
  x         = X_df,
  y         = y,
  method    = "xgbTree",
  trControl = train_ctrl,
  verbose   = FALSE
)

best_xgb <- fit_xgb$bestTune
sub_xgb  <- subset(
  fit_xgb$pred,
  nrounds == best_xgb$nrounds &
    max_depth == best_xgb$max_depth &
    eta == best_xgb$eta &
    gamma == best_xgb$gamma &
    colsample_bytree == best_xgb$colsample_bytree &
    min_child_weight == best_xgb$min_child_weight &
    subsample == best_xgb$subsample
)
sub_xgb <- sub_xgb[order(sub_xgb$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "XGB Tree",
    Cor   = cor(sub_xgb$obs, sub_xgb$pred),
    RMSE  = sqrt(mean((sub_xgb$obs - sub_xgb$pred)^2))
  )
)

# -------------------------------------------------------------------
# SVR (svmRadial)
# -------------------------------------------------------------------
cat("  - SVR (svmRadial)\n")

fit_svr <- caret::train(
  x          = X_df,
  y          = y,
  method     = "svmRadial",
  trControl  = train_ctrl,
  preProcess = c("center", "scale")
)

best_svr <- fit_svr$bestTune
sub_svr  <- subset(
  fit_svr$pred,
  sigma == best_svr$sigma & C == best_svr$C
)
sub_svr <- sub_svr[order(sub_svr$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "SVR (Radial)",
    Cor   = cor(sub_svr$obs, sub_svr$pred),
    RMSE  = sqrt(mean((sub_svr$obs - sub_svr$pred)^2))
  )
)

# -------------------------------------------------------------------
# Deep NN (RSNNS, mlpWeightDecayML)
# -------------------------------------------------------------------
cat("  - Deep Neural Network (mlpWeightDecayML)\n")

dnn_grid <- expand.grid(
  layer1 = c(64, 128),
  layer2 = c(32, 64),
  layer3 = c(16, 32),
  decay  = c(0.0001, 0.001)
)

fit_dnn <- caret::train(
  x          = X_df,
  y          = y,
  method     = "mlpWeightDecayML",
  tuneGrid   = dnn_grid,
  trControl  = train_ctrl,
  preProcess = c("center", "scale")
)

best_dnn <- fit_dnn$bestTune
sub_dnn  <- subset(
  fit_dnn$pred,
  layer1 == best_dnn$layer1 &
    layer2 == best_dnn$layer2 &
    layer3 == best_dnn$layer3 &
    decay  == best_dnn$decay
)
sub_dnn <- sub_dnn[order(sub_dnn$rowIndex), ]

results <- rbind(
  results,
  data.frame(
    Model = "Deep NN (RSNNS)",
    Cor   = cor(sub_dnn$obs, sub_dnn$pred),
    RMSE  = sqrt(mean((sub_dnn$obs - sub_dnn$pred)^2))
  )
)

# -------------------------------------------------------------------
# Final summary
# -------------------------------------------------------------------
cat("\n\n[ DONE — Results ]\n")
print(results)
